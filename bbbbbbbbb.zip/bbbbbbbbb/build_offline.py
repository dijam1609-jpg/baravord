# -*- coding: utf-8 -*-
"""ساخت نسخهٔ کاملاً آفلاین: SheetJS و همهٔ دارایی‌ها درون‌خطی، بدون هیچ درخواست شبکه‌ای."""
import os
from html.parser import HTMLParser

W = os.getcwd()
SRC = os.path.join(W, "files", "baravardkar-single.html")
OUT = os.path.join(W, "files", "baravardkar-offline.html")
LIB = "/tmp/xlsx/xlsx.full.min.js"

html = open(SRC, encoding="utf-8").read()
lib = open(LIB, encoding="utf-8").read()

assert "</script" not in lib, "library contains </script — cannot inline directly"

# ---------- ۱) درج موتور اکسل به‌صورت متن درون‌خطی (بدون اجرا در زمان بارگذاری) ----------
anchor_script = "<script>\n/* ========================================================="
assert anchor_script in html, "main script anchor not found"
xlsx_block = (
    "<!-- ============================================================\n"
    "     موتور اکسل SheetJS نسخهٔ 0.18.5 — کاملاً درون‌خطی برای اجرای آفلاین\n"
    "     (به‌صورت متن ذخیره شده و فقط در لحظهٔ نیاز اجرا می‌شود تا بارگذاری سبک بماند)\n"
    "     ============================================================ -->\n"
    '<script type="text/plain" id="xlsx-src">' + lib + "</script>\n\n"
)
html = html.replace(anchor_script, xlsx_block + anchor_script, 1)

# ---------- ۲) ensureXLSX → اجرای درون‌خطی (بدون CDN) ----------
old_ensure = """function ensureXLSX(cb){
  if(typeof XLSX!=='undefined'){ cb(); return; }
  const s=document.createElement('script');
  s.src='https://cdn.jsdelivr.net/npm/xlsx@0.18.5/dist/xlsx.full.min.js';
  s.onload=cb;
  s.onerror=()=>toast('کتابخانه اکسل بارگذاری نشد (اتصال اینترنت لازم است)');
  document.head.appendChild(s);
}"""
new_ensure = """let _xlsxQueue=[];
function ensureXLSX(cb){
  if(typeof XLSX!=='undefined'){ cb(); return; }
  /* موتور اکسل داخل همین فایل ذخیره شده است؛ بدون هیچ درخواست اینترنتی اجرا می‌شود */
  if(window.__xlsxBusy){ _xlsxQueue.push(cb); return; }
  window.__xlsxBusy=true; _xlsxQueue.push(cb);
  try{
    const node=document.getElementById('xlsx-src');
    if(!node) throw new Error('موتور اکسل درون‌خطی یافت نشد');
    (new Function(node.textContent||''))();
    if(typeof XLSX==='undefined') throw new Error('موتور اکسل بارگذاری نشد');
    const q=_xlsxQueue; _xlsxQueue=[];
    q.forEach(f=>{ try{ f(); }catch(e){ toast('خطا: '+e.message); } });
    paintOffline();
  }catch(e){
    _xlsxQueue=[];
    toast('اجرای موتور اکسل ناموفق: '+e.message);
  }finally{ window.__xlsxBusy=false; }
}"""
assert old_ensure in html, "ensureXLSX not found"
html = html.replace(old_ensure, new_ensure, 1)

# ---------- ۳) کارت «حالت آفلاین» در تنظیمات ----------
offline_card = """        <div class="card" id="card-offline">
          <h3>🔌 حالت کاملاً آفلاین</h3>
          <div id="offline-status"></div>
          <div class="guide" style="margin-top:8px">
            در این نسخه <b>هیچ منبع بیرونی</b> وجود ندارد: موتور اکسل، مانیفست، آیکون‌ها، استایل‌ها و همهٔ کدها
            داخل همین یک فایل هستند. بنابراین برنامه <b>بدون اینترنت</b> کامل کار می‌کند و برای اجرای آن
            <b>نیازی به سرویس‌ورکر نیست</b>. داده‌های شما هم در حافظهٔ خود دستگاه ذخیره می‌شوند.
          </div>
          <button class="btn ghost" style="margin-top:8px" onclick="offlineSelfTest()">🧪 آزمون خودکار حالت آفلاین</button>
        </div>
"""
anchor_card = '        <div class="card" id="card-install">'
assert anchor_card in html, "install card anchor not found"
html = html.replace(anchor_card, offline_card + anchor_card, 1)

# ---------- ۴) توابع آفلاین ----------
offline_js = r"""
/* =========================================================
   حالت کاملاً آفلاین — بررسی و آزمون بدون اینترنت
   ========================================================= */
function offlineChecks(){
  let storage=false;
  try{ localStorage.setItem('_bk_probe','1'); localStorage.removeItem('_bk_probe'); storage=true; }catch(e){}
  return [
    {ok:!!document.getElementById('xlsx-src'), label:'موتور اکسل (SheetJS) به‌صورت درون‌خطی'},
    {ok:!!document.getElementById('manifest-link'), label:'مانیفست اپلیکیشن به‌صورت درون‌خطی (data URI)'},
    {ok:!!document.querySelector('link[rel="apple-touch-icon"]'), label:'آیکون‌های برنامه به‌صورت درون‌خطی'},
    {ok:!!document.getElementById('install-guide'), label:'راهنمای نصب و کدهای برنامه درون همان فایل'},
    {ok:storage, label:'حافظهٔ محلی داده‌ها (localStorage) فعال'},
    {ok:typeof XLSX!=='undefined', label:'موتور اکسل در این نشست اجرا شده'}
  ];
}
function paintOffline(){
  const box=$('offline-status'); if(!box)return;
  const rows=offlineChecks();
  box.innerHTML=rows.map(r=>
    '<div style="display:flex;gap:8px;align-items:center;font-size:13px;padding:3px 0">'+
    '<span>'+((r.ok)?'✅':'▫️')+'</span><span>'+r.label+'</span></div>').join('')+
    '<div class="status">اتصال فعلی: <b>'+((navigator.onLine===false)?'آفلاین (بدون اینترنت)':'آنلاین')+'</b>'+
    ' — برنامه در هر دو حالت یکسان کار می‌کند و هیچ داده‌ای به اینترنت فرستاده نمی‌شود.</div>';
}
window.addEventListener('online',()=>{ if($('offline-status')) paintOffline(); });
window.addEventListener('offline',()=>{ if($('offline-status')) paintOffline(); toast('اتصال قطع شد — برنامه بدون اینترنت ادامه می‌دهد'); });
function offlineSelfTest(){
  ensureXLSX(()=>{});
  setTimeout(()=>{
    try{
      const ws=XLSX.utils.aoa_to_sheet([['آزمون آفلاین','مقدار'],[1,2],['جمع',3]]);
      const wb=XLSX.utils.book_new(); XLSX.utils.book_append_sheet(wb,ws,'آزمون');
      const bin=XLSX.write(wb,{bookType:'xlsx',type:'array'});
      const back=XLSX.read(bin,{type:'array'});
      const ok=back.SheetNames[0]==='آزمون';
      toast(ok?'✅ آزمون آفلاین موفق: ساخت و خواندن اکسل بدون اینترنت انجام شد':'⚠️ آزمون اکسل ناموفق بود');
    }catch(e){ toast('⚠️ خطا در آزمون آفلاین: '+e.message); }
    paintOffline();
  },80);
}
"""

anchor_offline_js = "/* =========================================================\n   PWA install — نصب روی گوشی از طریق مرورگر"
assert anchor_offline_js in html
html = html.replace(anchor_offline_js, offline_js + "\n" + anchor_offline_js, 1)

# ---------- ۵) فراخوانی در تنظیمات و init ----------
old_render_settings = "  $('od-log').textContent = state.od&&state.od.token ? 'وضعیت: متصل ✓' : 'وضعیت: بدون اتصال';"
assert old_render_settings in html
html = html.replace(old_render_settings, old_render_settings + "\n  paintOffline();", 1)

old_init2 = "  load(); $('hdr-date').textContent=today(); handleRedirect(); renderMain(); paintInstall();"
assert old_init2 in html
html = html.replace(old_init2, "  load(); $('hdr-date').textContent=today(); handleRedirect(); renderMain(); paintInstall(); paintOffline();", 1)

# ---------- ۶) متن‌ها و نسخه ----------
html = html.replace(
    "برآوردکار نسخهٔ ۲.۲ تک‌فایلی — همه‌چیز درون یک فایل (مانیفست و آیکون‌ها درون‌خطی) و قابل نصب روی گوشی",
    "برآوردکار نسخهٔ ۲.۳ کاملاً آفلاین — تک‌فایل، بدون اینترنت (بدون CDN، بدون سرویس‌ورکر) و قابل نصب روی گوشی"
)
html = html.replace(
    "return '<b>راهنمای نصب (نسخهٔ تک‌فایلی):</b>",
    "return '<b>راهنمای نصب (نسخهٔ تک‌فایلی و آفلاین):</b> این نسخه برای کار کردن به اینترنت نیازی ندارد؛ "
    "همهٔ کدها، موتور اکسل، مانیفست و آیکون‌ها داخل همین فایل هستند.<br>"
)
html = html.replace(
    "<title>برآوردکار — نسخهٔ تک‌فایلی | برآورد هزینه تعمیر و تکمیل ساختمان</title>",
    "<title>برآوردکار — نسخهٔ کاملاً آفلاین (تک‌فایل) | برآورد هزینه تعمیر و تکمیل ساختمان</title>"
)

with open(OUT, "w", encoding="utf-8") as f:
    f.write(html)

# ---------- ۷) اعتبارسنجی: متن درون‌خطی باید بایت‌به‌بایت با کتابخانه یکی باشد ----------
class Grab(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.on = False
        self.buf = []
    def handle_starttag(self, tag, attrs):
        if tag == "script" and dict(attrs).get("id") == "xlsx-src":
            self.on = True
    def handle_endtag(self, tag):
        if tag == "script" and self.on:
            self.on = False
    def handle_data(self, data):
        if self.on:
            self.buf.append(data)

g = Grab()
g.feed(html)
embedded = "".join(g.buf)
print("library bytes:", len(lib), "| embedded bytes:", len(embedded), "| identical:", embedded == lib)
assert embedded == lib, "embedded library mismatch — HTML parsing altered the payload"

# ---------- ۸) هیچ منبع شبکه‌ای اجباری باقی نمانده باشد ----------
import re
urls = sorted(set(re.findall(r'https?://[A-Za-z0-9._~:/?#\[\]@!$&\'()*+,;=%-]+', html)))
optional = ("login.microsoftonline.com", "graph.microsoft.com", "sheetjs.com", "w3.org", "openoffice.org",
            "schemas.openxmlformats.org", "ns.adobe.com", "purl.org", "microsoft.com", "aadcdn")
external = [u for u in urls if not any(o in u for o in optional)]
print("external runtime references:", external or "none")
print("size:", len(html.encode()), "bytes ->", OUT)
